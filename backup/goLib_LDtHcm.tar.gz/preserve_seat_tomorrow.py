import functools
import json
import random
import time
from keep_reserve import *
import websocket
import requests
from keep_session import *
from lib_configs import *
import schedule
import my_email
from threading import Thread
import ssl
from my_socket import *

# basic configs
seat_key, lib_id = the_seat_chosen[0], the_lib_chosen[0]
# save
params_confirm_seat = {
    "operationName": "save",
    "query": "mutation save($key: String!, $libid: Int!, $captchaCode: String, $captcha: String) {\n userAuth {\n prereserve {\n save(key: $key, libId: $libid, captcha: $captcha, captchaCode: $captchaCode)\n }\n }\n}",
    "variables": {
        # 这里的"key"：如果不是常用座位，需要在最后面加一个 '.'
        "key": seat_key + '.',
        "libid": lib_id,
        "captchaCode": "",
        "captcha": ""
    }
}
# libLayout
data_lib_chosen = {
    "operationName": "libLayout",
    "query": "query libLayout($libId: Int!) {\n userAuth {\n prereserve {\n libLayout(libId: $libId) {\n max_x\n max_y\n seats_booking\n seats_total\n seats_used\n seats {\n key\n name\n seat_status\n status\n type\n x\n y\n }\n }\n }\n }\n}",
    "variables": {
        "libId": lib_id
    }
}
# prereserve
params_confirm_seat_info = {"operationName": "prereserve",
                            "query": "query prereserve {\n userAuth {\n prereserve {\n prereserve {\n day\n lib_id\n "
                                     "seat_key\n seat_name\n is_used\n user_mobile\n id\n lib_name\n }\n }\n }\n}"}

url = 'https://wechat.v2.traceint.com/index.php/graphql/'

# queue_header = {
#     'Host': 'wechat.v2.traceint.com',
#     'Connection': 'Upgrade',
#     'Pragma': 'no-cache',
#     'Cache-Control': 'no-cache',
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x63090719) XWEB/8391 Flue',
#     'Upgrade': 'websocket',
#     'Origin': 'https://web.traceint.com',
#     'Sec-WebSocket-Version': '13',
#     'Accept-Encoding': 'gzip, deflate, br',
#     'Accept-Language': 'zh-CN,zh',
#     'Sec-WebSocket-Key': 'h/hkRDGbwZ1VCVfpL54B8w==',
#     'Sec-WebSocket-Extensions': 'permessage-deflate; client_max_window_bits',
#     # 'Cookie': cookieStr
# }

pre_header = {
    'Host': 'wechat.v2.traceint.com',
    'Connection': 'keep-alive',
    'Content-Length': '309',
    'App-Version': '2.0.14',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x63090719) XWEB/8391 Flue',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Origin': 'https://web.traceint.com',
    'Sec-Fetch-Site': 'same-origin',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Dest': 'empty',
    'Referer': 'https://web.traceint.com/',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh',
    # 'Cookie': cookieStr
}


def catch_exceptions(cancel_on_failure=False):
    def catch_exceptions_decorator(job_func):
        @functools.wraps(job_func)
        def wrapper(*args, **kwargs):
            try:
                return job_func(*args, **kwargs)
            except:
                import traceback
                print(traceback.format_exc())
                my_email.goLib_email_info('error')
                if cancel_on_failure:
                    return schedule.CancelJob
        return wrapper
    return catch_exceptions_decorator


def queue_pass(ws):
    # 连接socket进行排队的几种方法
    # 第一种方法
    # ws = websocket.WebSocket()
    # ws.connect('wss://wechat.v2.traceint.com/ws?ns=prereserve/queue', header=queue_header)  # 这里的XXXX和Host内容是一致的

    # 第二种方法
    # ws = websocket.create_connection('wss://wechat.v2.traceint.com/ws?ns=prereserve/queue',
    #                                  header=queue_header,
    #                                  sslopt={"cert_reqs": ssl.CERT_NONE})
    # if ws.connected:
    #     print('test pass queue connect')
    #     while True:
    #         ws.send('{"ns":"prereserve/queue","msg":""}')
    #         a = ws.recv()
    #         print(a)
    #         if a.find('u6392') != -1:  # 排队成功返回的第一个字符
    #             break
    #         if a.find('u6210') != -1:  # 已经抢座成功的返回
    #             print("rsp msg:{}".format(json.loads(str(a))["msg"]))
    #             time.sleep(5)
    #             break
    #         print("排队中，rsp:{}".format(a))
    #     # 关闭连接
    #     ws.close()
    # time.sleep(0.01)
    # print("排队结束。。。")
    # print("================================")

    """第三种方法"""
    # ws = CG_Client(
    #     url="wss://wechat.v2.traceint.com/ws?ns=prereserve/queue",
    #     headers=queue_header
    # )
    # 在抢座开始之前就已经建立好了这个socket，节省时间
    ws.connect()
    ws.run_forever()


def time_update():
    # struct_openTime = "****-**-** 21:00:00"
    now = time.gmtime()
    return now.tm_year.__str__() + '-' \
           + now.tm_mon.__str__() + '-' \
           + now.tm_mday.__str__() + ' ' \
           + '21:00:00'


# 开始时间
def preserve_tomorrow(session, file_name: str):
    # 更新cookie
    cookie = get_newest_cookie_by_txt(file_name)
    # queue_header['Cookie'] = cookie
    queue_header.append(('Cookie', cookie))
    pre_header['Cookie'] = cookie

    # 更新为当日抢座时间,open_time -> 时间戳
    struct_open_time = time_update()
    open_time = time.strptime(struct_open_time, "%Y-%m-%d %H:%M:%S")
    open_time = time.mktime(open_time)

    # 当前时间的时间戳
    timestamp = time.time()
    # 时间戳转换成localtime,
    # 形如：time.struct_time(tm_year=2023, tm_mon=9, tm_mday=25, tm_hour=12, tm_min=22, tm_sec=18,tm_wday=0, tm_yday=268, tm_isdst=0)
    time_local = time.localtime(timestamp)
    # 转换成新的时间格式(2016-05-05 20:28:54)
    dt = time.strftime("%Y-%m-%d %H:%M:%S", time_local)
    print('当前时间：', dt, ', 还有%f秒开始' % (open_time - timestamp))
    # 先建立一个socket
    ws = CG_Client(
        url="wss://wechat.v2.traceint.com/ws?ns=prereserve/queue",
        headers=queue_header
    )
    ws.connect()
    begin_time = open_time - 0.2
    while True:
        if time.time() >= begin_time:
            # print(time.time(), "⏰时间到，准备开始抢座!")
            # start_time = time.time()
            # queue_pass(ws)
            # 排队！直接省去函数调用！
            ws.run_forever()
            queue_time = time.time()
            # print(time.time(), '🚥queue ==> ok!')
            try:
                for seat in the_seat_chosen:
                    # 重要！如果不是放在常用座位，需要先请求对应的阅览室的所有座位，libLayout！！
                    session.post(
                        url=url,
                        headers=pre_header,
                        json=data_lib_chosen,  # libLayout
                        verify=False
                    )
                    # 抢座的post请求，core code
                    params_confirm_seat['variables']['key'] = seat + '.'
                    # print(params_confirm_seat)
                    text_save = session.post(
                        url=url,
                        headers=pre_header,
                        json=params_confirm_seat,  # save
                        verify=False
                    ).text
                    # print('⏰time when start queue:            ', start_time)
                    print('⏰time consumption in queue:        ', queue_time)
                    print('🚒save  ==> ok!')
                    print('⏰time consumption to preserve seat:', time.time() - queue_time)
                    # print(res.text)
                    text_res = session.post(
                        url=url,
                        headers=pre_header,
                        json=params_confirm_seat_info,  # prereserve
                        verify=False
                    ).text
                    print(time.ctime(), 'pre reserve:', str(text_res).encode('utf-8').decode('unicode_escape'))
                    print(time.ctime(), 'save       :', str(text_save).encode('utf-8').decode('unicode_escape'))

                    # if str(text_save).count("true") and text_res.count('user_mobile'):
                    if text_res.count('user_mobile'):
                        # 抢座成功就返回
                        print("😍恭喜你！明日预约成功！记得早起")
                        queue_header.pop()
                        try:
                            my_email.goLib_email_info('success', json.loads(text_res))
                        except Exception as e:
                            print(e)
                            print('获取每日诗词失败。。。')
                        return True
                    else:
                        ws = CG_Client(
                            url="wss://wechat.v2.traceint.com/ws?ns=prereserve/queue",
                            headers=queue_header
                        )
                        # 连续两次抢座之间间隔至少1s。。。。
                        time.sleep(1)
            except Exception as e:
                time.sleep(0.3)
                print(e)
            break
    print(time_update().split(' ')[0] + "的抢座结束！")
    return False


def keep_pre_reserve(session, file_name):
    # 重复3次！
    flag = False
    for i in range(0, 1):
        if preserve_tomorrow(session=session, file_name=file_name):
            flag = True
            break
    # 没抢到，通知一下
    if not flag:
        my_email.goLib_email_info('fail')


@catch_exceptions(cancel_on_failure=True)
def run_thread(arg):
    # print(arg)
    thread_lib = Thread(target=arg['func'], kwargs={
        'file_name': arg['file_name'],
        'session': arg['session']
    })
    thread_lib.start()


if __name__ == '__main__':
    # session 对象 =》 保活
    session = requests.session()
    print('🌠我去图书馆程序，启动！🌠 ', time.ctime())
    # 先进行一次session初始化设置，
    keep_session_newest(session=session, file_name='cookie_me.txt')
    # 每4~6分钟刷新cookie, 保活session
    schedule.every(5 * 60 + random.randint(-60, 60)).seconds.do(run_thread, arg={
        'func': keep_session_newest,
        'session': session,
        'file_name': 'cookie_me.txt'
    })
    # 每天21：59准时退座
    schedule.every().day.at("21:59:30").do(run_thread, arg={
        'func': withdraw_seat,
        'session': session,
        'file_name': ""
    })
    # 线程进行抢座！
    schedule.every().day.at("20:59:55").do(run_thread, arg={
        'func': keep_pre_reserve,
        'session': session,
        'file_name': 'cookie_me.txt'
    })
    # schedule.every().day.at("20:59:00").do(run_thread, {
    #     'func': preserve_tomorrow,
    #     'session': session,
    #     'file_name': 'cookie_me.txt'
    # })

    while True:
        schedule.run_pending()
        time.sleep(1)
