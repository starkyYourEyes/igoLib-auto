import http.cookies
import requests
import json
import time
import random
from threading import Thread
import my_email

# 持久化存储cookie，同时文件中的cookie可以共享给其他程序
def save_cookies(cookie_str, file_name='cookie_me.txt'):
    with open(file_name, 'w', encoding='utf-8') as fp:
        fp.write(cookie_str)


# 从文件中读取最新的cookie
def get_newest_cookie_by_txt(file_name='cookie_me.txt'):
    with open(file_name, 'r', encoding='utf-8') as fp:
        read_cookie = fp.read()
    return read_cookie.strip('\r\n')


def keep_session_newest(session, file_name):
    cookie = http.cookies.SimpleCookie()
    cookie.load(get_newest_cookie_by_txt(file_name))
    for key, morsel in cookie.items():
        session.cookies.set(key, morsel)
    # print(session.cookies)
    if session.cookies.keys().count("Authorization") > 1:
        session.cookies.set("Authorization", domain="", value=None)
    res = session.post("http://wechat.v2.traceint.com/index.php/graphql/", json={
        "query": 'query getUserCancleConfig { userAuth { user { holdValidate: getSchConfig(fields: "hold_validate", extra: true) } } }',
        "variables": {},
        "operationName": "getUserCancleConfig"
    })
    # print(res.request.headers['Cookie'])
    # 持久化存储cookie
    save_cookies(res.request.headers['Cookie'], file_name)
    # session.headers.clear(), session.headers.update(res.request.headers['Cookie'])
    try:
        result = res.json()
    except json.decoder.JSONDecodeError as err:
        print("Error: %s" % err)
    if result.get("errors") and result.get("errors")[0].get("code") != 0:
        print("result: ", result)
        print("😥Session expired!😥")
        my_email.goLib_email_info('SessionError')
    else:
        print("✅Session OK.✅ ", time.ctime())
        # if file_name.count('me'):
        #     print("✅Z's Session OK.✅ ", time.ctime())
        # else:
        #     print("✔T's Session OK.✔")


def keep_session_start(**kwargs):
    keep_session_newest(
        session=kwargs['session'],
        file_name=kwargs['file_name']
    )


if __name__ == '__main__':
    keep_session_start(" ")
