import json
import time
from typing import Union
# start = time.time()
# ws = CG_Client(
#     url="wss://wechat.v2.traceit.com/ws?ns=prereserve/queue",
#     headers=queue_header
# )
# end = time.time()
# print(end - start)
# ws.connect()
# ws.run_forever()
# print(222)
#
# try:
#     print(1 / 0)
# except Exception as e:
#     print(e)
#
# print('yes')
info = {
    "data": {
        "userAuth": {
            "prereserve": {
                "prereserve": {
                    "day": 20230917,
                    "lib_id": 122265,
                    "seat_key": "4,22",
                    "seat_name": "7",
                    "is_used": 0,
                    "user_mobile": "18552235831",
                    "id": 0,
                    "lib_name": "三楼北语言文学"
                }
            }
        }
    }
}


# def func_default_argument(msg: dict | str = 'default msg'):
def func_default_argument(msg: Union[dict, str] = 'default info'):
    # ss = '234'
    # print(ss['2'])

    # msg = {
    #     '笑哭': '😂',
    #     '无语': '😅'
    # }
    # print(msg['无语'])
    print(msg['s']['s']['aaa'])
    print(msg, end=': ')
    if type(msg) == dict:
        print('dict')
    elif type(msg) == str:
        print('str')


# func_default_argument({'22': '22'})
# func_default_argument('123')
#
# func_default_argument()
# print(f'#{4:18}')
# func_default_argument('1')
# tes = [1, 2]
# def testt():
#     global tes
#     tes = [3]
#
# print(tes)
# testt()
# print(tes)

# print(info['data']['userAuth']['prereserve']['prereserve']['lib_name'])
# print(info['data']['userAuth']['prereserve']['prereserve']['seat_name'])
# from my_socket import *
# def test():
#     queue_header.append('1')
#     print(queue_header)
#
#
# test()
# print('===================')
# test()
# print_que()

# import requests
# url = 'https://redmap.ikarox.cn/mems?id=1'
# print(type(requests.get(url).json()))

# def arg_test(**kwargs):
#     print(kwargs)
#     print(kwargs['name'])
#     print(kwargs['age'])
#
#
# def arg_demo(*args):
#     print(args)
#
#
# arg_demo((123, 234))
#
#
# arg_test(**{
#     'name': '123',
#     'age': 2
# })


# def test_param(name):
#     print(name)
#
#
# # test_param(8)
# print('hello'.__contains__('e'))

# resp_msg = '{"ns":"prereserve\/queue","msg":"\u4e0d\u5728\u9884\u7ea6\u65f6\u95f4\u5185,\u8bf7\u5728 21:00-23:59 \u6765\u9884\u7ea6","code":0,"data":0}'
#
# start = time.time()
# print(resp_msg)
# if resp_msg.find('u6392') != -1:  # 排队成功返回的第一个字符
#     print('queue over')
#     # self.close()
# elif resp_msg.find('u6210') != -1:  # 已经抢座成功的返回
#     print("rsp msg:{}".format(json.loads(resp_msg)["msg"]))
#     # self.close()
#     time.sleep(1)
# else:
#     pass
# print(time.time() - start)
# for _ in range(10):
#     try:
#         x = 1 / 0
#     except Exception as e:
#         print(e)
#         break
#     finally:
#         print('finally')
#     print(222)


# for _ in range(10):
#     print(_, time.time())
#     time.sleep(0.03)
i = 1
while i <= 0:
    i += 1
    print(i, end=', ')
else:
    print('\n', i + 1)
