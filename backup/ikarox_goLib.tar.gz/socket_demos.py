import json
from ws4py.client.threadedclient import WebSocketClient
from keep_session import *
import websocket
import ssl
import base64
import os
queue_header = {
    'Host': 'wechat.v2.traceint.com',
    'Connection': 'Upgrade',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x63090719) XWEB/8391 Flue',
    'Upgrade': 'websocket',
    'Origin': 'https://web.traceint.com',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh',
    'Sec-WebSocket-Version': '13',
    'Sec-WebSocket-Key': 'h/hkRDGbwZ1VCVfpL54B8w==',
    'Sec-WebSocket-Extensions': 'permessage-deflate; client_max_window_bits',
    # 'Cookie': cookieStr
}
headers = [
    ('Host', 'wechat.v2.traceint.com'),
    ('Connection', 'Upgrade'),
    ('Upgrade', 'websocket'),
    # ('Pragma', 'no-cache'),
    # ('Cache-Control', 'no-cache'),
    ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x63090719) XWEB/8391 Flue'),
    ('Origin', 'https://web.traceint.com'),
    # ('Accept-Encoding', 'gzip, deflate, br'),
    # ('Accept-Language', 'zh-CN,zh'),
    ('Sec-WebSocket-Extensions', 'permessage-deflate; client_max_window_bits'),
    ('Sec-WebSocket-Key', 'J5PSBxALx6TJAVyRXIhl0g=='),
    ('Sec-WebSocket-Version', '13'),
    ('Cookie', get_newest_cookie_by_txt())
]
def pass_queue():
    print("================================")
    print("开始排队。。。")
    # ws = websocket.WebSocket()
    # ws.connect('wss://wechat.v2.traceint.com/ws?ns=prereserve/queue', header=queue_header)  # 这里的XXXX和Host内容是一致的
    ws = websocket.create_connection('wss://wechat.v2.traceint.com/ws?ns=prereserve/queue', header=queue_header, sslopt={"cert_reqs": ssl.CERT_NONE})

    if ws.connected:
        print('test pass queue connect')
        while True:
            ws.send('{"ns":"prereserve/queue","msg":""}')
            a = ws.recv()
            print(a)
            if a.find('u6392') != -1:  # 排队成功返回的第一个字符
                break
            if a.find('u6210') != -1:  # 已经抢座成功的返回
                print("rsp msg:{}".format(json.loads(str(a))["msg"]))
                time.sleep(5)
                break
            print("排队中，rsp:{}".format(a))
            # time.sleep(0.01)
        # 关闭连接
        ws.close()
    time.sleep(0.01)

    print("排队结束。。。")
    print("================================")


def socket_key_random():
    # 生成16字节的随机值
    random_bytes = os.urandom(16)
    # 使用base64编码
    return base64.b64encode(random_bytes).decode('utf-8')
    # print("Sec-WebSocket-Key:", sec_websocket_key)



class CG_Client(WebSocketClient):
    def opened(self):
        req = '{"ns":"prereserve/queue","msg":""}'
        self.send(req)

    def closed(self, code, reason=None):
        print("Closed down:", code, reason)

    def received_message(self, resp):
        resp = json.loads(str(resp))
        data = resp['msg']
        print(type(data), data)
        # print(data)
        if type(data) is str:
            if data.find('u6392') != -1:  # 排队成功返回的第一个字符
                print('queue over')
                self.close()
            if data.find('u6210') != -1:  # 已经抢座成功的返回
                print("rsp msg:{}".format(json.loads(str(data))["msg"]))
                self.close()
                time.sleep(5)


if __name__ == '__main__':
    ws = None
    try:
        queue_header['Cookie'] = get_newest_cookie_by_txt('cookie_me.txt')
        ws = CG_Client(
            url="wss://wechat.v2.traceint.com/ws?ns=prereserve/queue",
            headers=headers
        )
        print('yes1')
        # ws = CG_Client(url='wss://i.cg.net/wi/ws', headers=)
        ws.connect()
        print('yes2')
        ws.run_forever()
        print('yes3')

        # ws.opened()

        # if ws.handshake_ok():
        while True:
            ws.opened()
            print("排队中")
            # time.sleep(0.01)
            # 关闭连接

    except KeyboardInterrupt:
        ws.close()

# if __name__ == '__main__':
#     for i in range(10):
#         print(socket_key_random())