# import asyncio
# from websockets.sync.client import connect
#
# def hello():
#     with connect("ws://localhost:8765") as websocket:
#         websocket.send("Hello world!")
#         websocket.send("Hello world!")
#         websocket.send("Hello world!")
#         message = websocket.recv()
#         print(f"Received: {message}")
#         message = websocket.recv()
#         print(f"Received: {message}")
#         message = websocket.recv()
#         print(f"Received: {message}")
#
# hello()


import json
import asyncio
import pathlib
import ssl
import time
import websockets


uri = "wss://wechat.v2.traceint.com/ws?ns=prereserve/queue"
# uri = "wss://wechat.v2.traceint.com/ws?ns=prereserve/queue"
queue_header = {
    'Host': 'wechat.v2.traceint.com',
    'Connection': 'Upgrade',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x63090719) XWEB/8391 Flue',
    'Upgrade': 'websocket',
    'Origin': 'https://web.traceint.com',
    'Sec-WebSocket-Version': '13',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh',
    # 'Sec-WebSocket-Key': 'h/hkRDGbwZ1VCVfpL54B8w==',
    'Sec-WebSocket-Extensions': 'permessage-deflate; client_max_window_bits',
    # # lsy
    'Cookie': 'Authorization=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1c2VySWQiOjMyNjcxMzA3LCJzY2hJZCI6MTI1LCJleHBpcmVBdCI6MTY5ODM0MDQ2OX0.p_MI29odP9kd6HLxQ2zPg1OxyrJAVxhNrkQl28i54iVOd10Hz8js0uJoei7MLGW0C3mvddsMSdldOeBllbRkeLTT17kP5gtHFZ_9XoUEPU4Wh6CdYy0m6cwO3sI5MP4PQiqUrGcvGHNNk8NzS1Sm2kW-MCj2mPHy4zCWwSTvJAFIVq9lym1OBE-6BudvwKTYhTtvrJiSkFnnnEfy6yeWWqhHMrgifTHDT88X92KRQMg4AfUM8-mUEJlpoUw6iOGUyP9wRqHmfeSsh8G7rxHhWw1ShVnqjecE-QiPjJL7GfXshr8YzR2gzAXZ-Es1Ul_m0tw5ea8PaZAuaV6rgK6v2A; SERVERID=d3936289adfff6c3874a2579058ac651|1698333269|1698333269'
    # # zh
    # 'Cookie': 'Authorization=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1c2VySWQiOjMzNTA3NDIxLCJzY2hJZCI6MTI1LCJleHBpcmVBdCI6MTY5ODM0MTU3N30.s4PXKb1siGoHDCkRWJlz46SVA41yZZA452l_zhsb2CuYIZNxQKVhF8hZoXn6-ml6qR5TJ_blJAVQ60j7C4tX4Ah3PfejASKnqk9UiqTXXBFLO4ArgAlGGRcOW3ZFx3PPQ09HT6cQ1-6czTcrEj7tNAGgda2kxony4SbJK1CEDw22VsU0DnSA8ffIEW-MwPrf33YVOqDsSF3PlX5pVPdwTVaJyGnwxpoU4D0pt4ZuEliac8ApY0Kg_q4l5o1YBGfFV_QJSrYbQXnR3JrqFFSHpl4aR6-VgG5HTF8P40DlrFxijW6WfVmhY1d5B-3YRKzE9yTtlj6GxhVmWhhDmwh_1A; SERVERID=e3fa93b0fb9e2e6d4f53273540d4e924|1698334377|1698334377'
}
cnt = 0
start = None
end_time = None
# 创建一个 SSL 上下文并指定协议版本
ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE


start_queue_time = time.time()
open_time = time.time() + 2


async def queue_pass():
    async with websockets.connect("wss://wechat.v2.traceint.com/ws?ns=prereserve/queue",
                                  extra_headers=queue_header,
                                  ssl=ssl_context) as websocket:
        start = time.time()
        while True:
            try:
                while start_queue_time <= time.time() <= open_time:
                    print('msg1', time.time())
                    await websocket.send('{"ns":"prereserve/queue","msg":""}')
                    time.sleep(0.01)
                else:
                    # 没到设定的开始排队的时间，不不要开始，while不成立或者while执行结束就会执行else
                    if time.time() >= open_time:
                        print('msg2', time.time())
                        await websocket.send('{"ns":"prereserve/queue","msg":""}')

                ans = await websocket.recv()
                print(ans, time.time())
                if ans.find('u6392') != -1:  # 成功排队，2分钟内。。。。
                    print('time consumption in queue:', time.time() - open_time)
                    print('open_time is:', time.time())
                    print('now time1:', time.time())
                    print(json.loads(ans)["msg"])

                    return
                # json.loads ==> unicode自动转中文
            except Exception as e:
                print(e)

    print('now time2:', time.time())

if __name__ == "__main__":
    print('1111')
    asyncio.run(queue_pass())
    print('now time3:', time.time())
    print('2222')
