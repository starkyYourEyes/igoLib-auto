import websocket
import time
import json
import ssl

queue_header = {
    'Host': 'wechat.v2.traceint.com',
    'Connection': 'Upgrade',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 NetType/WIFI MicroMessenger/7.0.20.1781(0x6700143B) WindowsWechat(0x63090719) XWEB/8391 Flue',
    'Upgrade': 'websocket',
    'Origin': 'https://web.traceint.com',
    'Sec-WebSocket-Version': '13',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh',
    'Sec-WebSocket-Key': 'h/hkRDGbwZ1VCVfpL54B8w==',
    'Sec-WebSocket-Extensions': 'permessage-deflate; client_max_window_bits',
    # 'Cookie': cookieStr
}
def on_message(ws, message):  # 服务器有数据更新时，主动推送过来的数据
    print('receive:', message)      # str
    # print('type of receive', type(message))
    if message.find('u6392') != -1:  # 排队成功返回的第一个字符
        print('queue over')
        ws.close()
    elif message.find('u6210') != -1:  # 已经抢座成功的返回
        print("rsp msg:{}".format(json.loads(str(message))["msg"]))
        ws.close()
        time.sleep(5)
    else:
        pass
        # on_open(ws)


def on_error(ws, error):  # 程序报错时，就会触发on_error事件
    print('error:', error)


def on_close(ws, a, b):
    print("Connection closed ……")


def on_open(ws):  # 连接到服务器之后就会触发on_open事件，这里用于send数据
    req = '{"ns":"prereserve/queue","msg":""}'
    print(req)
    ws.send(req)


if __name__ == "__main__":
    websocket.enableTrace(True)
    ws = websocket.WebSocketApp("wss://wechat.v2.traceint.com/ws?ns=prereserve/queue",
                                header=queue_header,
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close)
    ws.on_open = on_open
    ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})
