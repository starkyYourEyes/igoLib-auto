#!/bin/bash
cd /www/wwwroot/python/igoLib/
nohup /www/server/pyporject_evn/dcdda004faff0b58441331ef52da9695_venv/bin/python3 -u /www/wwwroot/python/igoLib/preserve_seat_tomorrow.py >> /www/wwwlogs/python/igoLib/error.log 2>&1 &