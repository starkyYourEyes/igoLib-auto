#!/bin/bash
ps -ef | grep preserve_seat_tomorrow.py | grep -v grep | awk '{print $2}' | xargs kill -9