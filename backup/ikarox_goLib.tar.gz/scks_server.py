import asyncio
import time

from websockets.server import serve

async def echo(websocket):
    async for message in websocket:
        # time.sleep(1)
        print('server receive msg from client', message, time.time())
        await websocket.send(message)

async def main():
    async with serve(echo, "localhost", 8765):
        await asyncio.Future()  # run forever

asyncio.run(main())